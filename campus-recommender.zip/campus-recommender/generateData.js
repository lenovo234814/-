const fs = require('fs');

// ========== 生成100个物品 ==========
const categories = ['数码产品', '教材书籍', '体育用品', '生活电器', '服饰鞋包', '乐器', '游戏设备'];
const items = [];

for (let i = 1; i <= 100; i++) {
    const category = categories[Math.floor(Math.random() * categories.length)];
    items.push({
        item_id: i,
        title: `${category}-${String(i).padStart(3, '0')}号`,
        category: category,
        price: Math.floor(Math.random() * 490) + 10
    });
}

fs.writeFileSync('items.json', JSON.stringify(items, null, 2));
console.log(`✅ 已生成 ${items.length} 个物品`);

// ========== 生成用户评分 ==========
const ratings = [];
for (let user_id = 1; user_id <= 50; user_id++) {
    const ratedCount = Math.floor(Math.random() * 11) + 20;
    const ratedItems = new Set();
    const favCategory = categories[Math.floor(Math.random() * categories.length)];
    
    while (ratedItems.size < ratedCount) {
        const itemId = Math.floor(Math.random() * 100) + 1;
        ratedItems.add(itemId);
    }
    
    ratedItems.forEach(itemId => {
        const item = items.find(i => i.item_id === itemId);
        const rating = item.category === favCategory ? 
            Math.floor(Math.random() * 2) + 4 : 
            Math.floor(Math.random() * 3) + 1;
        ratings.push({ user_id, item_id: itemId, rating });
    });
}

fs.writeFileSync('ratings.json', JSON.stringify(ratings, null, 2));
console.log(`✅ 已生成 ${ratings.length} 条评分记录`);
console.log('🎉 数据生成完成！');
const itemsData = require('./items.json');
const ratingsData = require('./ratings.json');

// ========== 计算用户相似度（皮尔逊相关系数）==========
function pearsonCorrelation(user1, user2) {
    const user1Ratings = ratingsData.filter(r => r.user_id === user1);
    const user2Ratings = ratingsData.filter(r => r.user_id === user2);
    
    // 找两人共同评分的物品
    const commonItems = user1Ratings
        .filter(r1 => user2Ratings.some(r2 => r2.item_id === r1.item_id))
        .map(r1 => r1.item_id);
    
    if (commonItems.length === 0) return 0;
    
    // 计算评分均值
    const u1Mean = user1Ratings.reduce((s, r) => s + r.rating, 0) / user1Ratings.length;
    const u2Mean = user2Ratings.reduce((s, r) => s + r.rating, 0) / user2Ratings.length;
    
    let numerator = 0, denom1 = 0, denom2 = 0;
    commonItems.forEach(itemId => {
        const r1 = user1Ratings.find(r => r.item_id === itemId).rating;
        const r2 = user2Ratings.find(r => r.item_id === itemId).rating;
        numerator += (r1 - u1Mean) * (r2 - u2Mean);
        denom1 += Math.pow(r1 - u1Mean, 2);
        denom2 += Math.pow(r2 - u2Mean, 2);
    });
    
    return denom1 === 0 || denom2 === 0 ? 0 : numerator / (Math.sqrt(denom1) * Math.sqrt(denom2));
}

// ========== 推荐函数 ==========
function recommend(userId, topN = 10) {
    // 1. 找所有其他用户
    const allUsers = [...new Set(ratingsData.map(r => r.user_id))];
    
    // 2. 计算该用户与其他所有用户的相似度
    const similarities = allUsers
        .filter(uid => uid !== userId)
        .map(uid => ({ userId: uid, sim: pearsonCorrelation(userId, uid) }))
        .sort((a, b) => b.sim - a.sim)
        .slice(0, 5); // 取Top5相似用户
    
    // 3. 找这些用户喜欢但目标用户没评分的物品
    const userRatedItems = new Set(
        ratingsData.filter(r => r.user_id === userId).map(r => r.item_id)
    );
    
    const scoreMap = new Map();
    similarities.forEach(({ userId: uid, sim }) => {
        const userRatings = ratingsData.filter(r => r.user_id === uid);
        userRatings.forEach(r => {
            if (!userRatedItems.has(r.item_id)) {
                const current = scoreMap.get(r.item_id) || { sum: 0, weight: 0 };
                current.sum += sim * r.rating;
                current.weight += Math.abs(sim);
                scoreMap.set(r.item_id, current);
            }
        });
    });
    
    // 4. 计算加权分数并排序
    const recommendations = Array.from(scoreMap.entries())
        .map(([itemId, { sum, weight }]) => ({
            item_id: parseInt(itemId),
            score: weight === 0 ? 0 : sum / weight
        }))
        .sort((a, b) => b.score - a.score)
        .slice(0, topN);
    
    // 5. 返回物品详情
    return recommendations.map(rec => {
        const item = itemsData.find(i => i.item_id === rec.item_id);
        return { ...item, match_score: Math.round(rec.score * 20) };
    });
}

module.exports = { recommend };
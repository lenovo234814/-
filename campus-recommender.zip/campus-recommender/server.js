const express = require('express');
const cors = require('cors');
const { recommend } = require('./recommend');
const itemsData = require('./items.json');

const app = express();
app.use(cors());
app.use(express.json());

// 测试接口
app.get('/test', (req, res) => {
    res.json({ msg: '后端运行正常！' });
});

// 推荐接口
app.get('/recommend', (req, res) => {
    const userId = parseInt(req.query.user_id) || 1;
    
    try {
        const recommendations = recommend(userId);
        res.json({ code: 0, data: recommendations });
    } catch (error) {
        // 如果用户不存在，返回热门物品（冷启动）
        const hotItems = itemsData.slice(0, 10);
        res.json({ code: 0, data: hotItems });
    }
});

// 发布接口
app.post('/publish', (req, res) => {
    const { title, category, price } = req.body;
    const newItem = {
        item_id: itemsData.length + 1,
        title,
        category,
        price: parseInt(price)
    };
    itemsData.push(newItem);
    res.json({ code: 0, msg: '发布成功！', data: newItem });
});

// ===== 热门接口 =====
app.get('/hot', (req, res) => {
  const ratings = require('./ratings.json')
  const itemCount = {}
  ratings.forEach(r => {
    itemCount[r.item_id] = (itemCount[r.item_id] || 0) + 1
  })
  const sorted = Object.entries(itemCount)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 10)
    .map(([itemId]) => parseInt(itemId))
  
  const hotItems = itemsData.filter(item => sorted.includes(item.item_id))
  res.json({ code: 0, data: hotItems })
})

// ===== 搜索接口 =====
app.get('/search', (req, res) => {
  const keyword = req.query.keyword || ''
  const results = itemsData.filter(item => 
    item.title.includes(keyword) || item.category.includes(keyword)
  )
  res.json({ code: 0, data: results })
})
app.listen(5000, () => {
    console.log('🚀 服务器运行在 http://localhost:5000');
    console.log('📝 测试地址: http://localhost:5000/test');
    console.log('📝 推荐地址: http://localhost:5000/recommend?user_id=1');
});